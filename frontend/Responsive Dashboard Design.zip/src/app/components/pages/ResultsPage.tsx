import React from "react";
import { useNavigate } from "react-router";
import { motion } from "motion/react";
import {
  RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Cell
} from "recharts";
import { ProgressRing } from "../ui/ProgressRing";
import { GlassCard } from "../ui/GlassCard";
import { Badge } from "../ui/Badge";
import { Brain, CheckCircle2, AlertCircle, Play, Download, Share2, Trophy } from "lucide-react";

const breakdowns = [
  { label: "NLP Content Score", value: 88, color: "#6366F1", icon: Brain, desc: "Accuracy, depth, and structure of your answers" },
  { label: "Voice Fluency Score", value: 79, color: "#22C55E", icon: Brain, desc: "Pace, clarity, and articulation of speech" },
  { label: "Facial Expression Score", value: 82, color: "#F59E0B", icon: Brain, desc: "Eye contact, expressions, and engagement" },
  { label: "Behavioral Structure", value: 87, color: "#EC4899", icon: Brain, desc: "STAR method usage and structured responses" },
];

const radarData = [
  { subject: "Technical", value: 88 },
  { subject: "Communication", value: 79 },
  { subject: "Problem Solving", value: 85 },
  { subject: "Confidence", value: 76 },
  { subject: "Clarity", value: 82 },
  { subject: "Time Mgmt", value: 71 },
];

const barData = [
  { name: "Q1", score: 90 },
  { name: "Q2", score: 84 },
  { name: "Q3", score: 72 },
  { name: "Q4", score: 88 },
  { name: "Q5", score: 85 },
];

const strengths = [
  "Clear and structured explanation of concepts",
  "Strong technical accuracy in DSA topics",
  "Good use of examples and analogies",
];
const weaknesses = [
  "Eye contact could be more consistent",
  "Speaking pace was too fast in Q3",
  "Could improve use of pauses for emphasis",
];

const customTooltipStyle = {
  contentStyle: { backgroundColor: "#1E293B", border: "1px solid #334155", borderRadius: "12px" },
  labelStyle: { color: "#94A3B8", fontSize: "0.75rem" },
  itemStyle: { color: "#F1F5F9", fontSize: "0.8rem" },
};

export function ResultsPage() {
  const navigate = useNavigate();

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 style={{ fontSize: "1.6rem", fontWeight: 800 }} className="text-[#F1F5F9]">Interview Results</h1>
          <p style={{ fontSize: "0.875rem" }} className="text-[#94A3B8] mt-1">Technical · Data Structures · Medium · 5 Questions · Feb 28, 2026</p>
        </div>
        <div className="flex items-center gap-2">
          <button style={{ fontSize: "0.8rem", fontWeight: 500 }} className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-[#334155] bg-[#1E293B] text-[#94A3B8] hover:text-[#F1F5F9] transition-colors">
            <Download size={14} /> Export
          </button>
          <button style={{ fontSize: "0.8rem", fontWeight: 500 }} className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-[#334155] bg-[#1E293B] text-[#94A3B8] hover:text-[#F1F5F9] transition-colors">
            <Share2 size={14} /> Share
          </button>
        </div>
      </div>

      {/* Overall score hero */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <GlassCard className="p-8 relative overflow-hidden">
          {/* Background glow */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-80 h-48 rounded-full blur-3xl pointer-events-none"
            style={{ background: "radial-gradient(ellipse, rgba(99,102,241,0.2) 0%, transparent 70%)" }} />

          <div className="relative z-10 flex flex-col md:flex-row items-center gap-10">
            <div className="flex flex-col items-center gap-4">
              <ProgressRing
                value={84}
                size={180}
                strokeWidth={14}
                color="#6366F1"
                trackColor="#0F172A"
                label="Overall Score"
                sublabel="/ 100"
              />
              <div className="flex items-center gap-2">
                <Trophy size={16} className="text-yellow-400" />
                <span style={{ fontSize: "0.85rem", fontWeight: 600 }} className="text-[#F1F5F9]">Great Performance!</span>
              </div>
            </div>

            <div className="flex-1 grid grid-cols-2 gap-4 w-full">
              {breakdowns.map(({ label, value, color }, i) => (
                <motion.div
                  key={label}
                  className="flex flex-col gap-2 p-4 rounded-xl bg-[#0F172A] border border-[#334155]"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.1 + i * 0.07 }}
                >
                  <p style={{ fontSize: "0.72rem", fontWeight: 600 }} className="text-[#94A3B8] uppercase tracking-wider">{label}</p>
                  <div className="flex items-end gap-2">
                    <span style={{ fontSize: "1.8rem", fontWeight: 800, color }}>{value}</span>
                    <span style={{ fontSize: "0.75rem" }} className="text-[#475569] mb-1">/100</span>
                  </div>
                  <div className="w-full bg-[#1E293B] rounded-full h-1.5">
                    <div className="h-1.5 rounded-full transition-all duration-700" style={{ width: `${value}%`, backgroundColor: color }} />
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </GlassCard>
      </motion.div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Radar chart */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
        >
          <GlassCard className="p-6 h-full">
            <div className="flex items-center justify-between mb-5">
              <h3 style={{ fontSize: "0.95rem", fontWeight: 700 }} className="text-[#F1F5F9]">Skills Radar</h3>
              <Badge variant="purple">6 Dimensions</Badge>
            </div>
            <ResponsiveContainer width="100%" height={260}>
              <RadarChart data={radarData} cx="50%" cy="50%" outerRadius="70%">
                <PolarGrid stroke="#334155" />
                <PolarAngleAxis
                  dataKey="subject"
                  tick={{ fill: "#94A3B8", fontSize: 11 }}
                />
                <Radar
                  name="Score"
                  dataKey="value"
                  stroke="#6366F1"
                  fill="#6366F1"
                  fillOpacity={0.25}
                  strokeWidth={2}
                />
              </RadarChart>
            </ResponsiveContainer>
          </GlassCard>
        </motion.div>

        {/* Bar chart */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
        >
          <GlassCard className="p-6 h-full">
            <div className="flex items-center justify-between mb-5">
              <h3 style={{ fontSize: "0.95rem", fontWeight: 700 }} className="text-[#F1F5F9]">Per-Question Scores</h3>
              <Badge variant="green">5 Questions</Badge>
            </div>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={barData} barSize={32}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" vertical={false} />
                <XAxis dataKey="name" tick={{ fill: "#94A3B8", fontSize: 12 }} axisLine={false} tickLine={false} />
                <YAxis domain={[0, 100]} tick={{ fill: "#94A3B8", fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip {...customTooltipStyle} cursor={{ fill: "rgba(99,102,241,0.08)" }} />
                <Bar dataKey="score" radius={[6, 6, 0, 0]}>
                  {barData.map((entry, i) => (
                    <Cell
                      key={i}
                      fill={entry.score >= 85 ? "#22C55E" : entry.score >= 75 ? "#6366F1" : "#F59E0B"}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </GlassCard>
        </motion.div>
      </div>

      {/* Feedback section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
          <GlassCard className="p-6 h-full">
            <div className="flex items-center gap-2 mb-5">
              <div className="w-7 h-7 rounded-lg bg-[#22C55E]/20 flex items-center justify-center">
                <CheckCircle2 size={16} className="text-[#22C55E]" />
              </div>
              <h3 style={{ fontSize: "0.95rem", fontWeight: 700 }} className="text-[#F1F5F9]">Strengths</h3>
            </div>
            <div className="flex flex-col gap-3">
              {strengths.map((s, i) => (
                <div key={i} className="flex items-start gap-3 p-3 rounded-xl bg-[#22C55E]/5 border border-[#22C55E]/20">
                  <CheckCircle2 size={15} className="text-[#22C55E] flex-shrink-0 mt-0.5" />
                  <p style={{ fontSize: "0.85rem", lineHeight: 1.5 }} className="text-[#F1F5F9]">{s}</p>
                </div>
              ))}
            </div>
          </GlassCard>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.45 }}>
          <GlassCard className="p-6 h-full">
            <div className="flex items-center gap-2 mb-5">
              <div className="w-7 h-7 rounded-lg bg-[#F59E0B]/20 flex items-center justify-center">
                <AlertCircle size={16} className="text-[#F59E0B]" />
              </div>
              <h3 style={{ fontSize: "0.95rem", fontWeight: 700 }} className="text-[#F1F5F9]">Areas to Improve</h3>
            </div>
            <div className="flex flex-col gap-3">
              {weaknesses.map((w, i) => (
                <div key={i} className="flex items-start gap-3 p-3 rounded-xl bg-[#F59E0B]/5 border border-[#F59E0B]/20">
                  <AlertCircle size={15} className="text-[#F59E0B] flex-shrink-0 mt-0.5" />
                  <p style={{ fontSize: "0.85rem", lineHeight: 1.5 }} className="text-[#F1F5F9]">{w}</p>
                </div>
              ))}
            </div>
          </GlassCard>
        </motion.div>
      </div>

      {/* CTA */}
      <motion.div
        className="flex flex-col sm:flex-row gap-3 justify-center py-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
      >
        <button
          onClick={() => navigate("/interview")}
          className="flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl text-white hover:scale-105 transition-transform"
          style={{ background: "linear-gradient(135deg, #6366F1, #4F46E5)", fontSize: "0.95rem", fontWeight: 700 }}
        >
          <Play size={18} />
          Start Another Interview
        </button>
        <button
          onClick={() => navigate("/app")}
          style={{ fontSize: "0.95rem", fontWeight: 600 }}
          className="flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl border border-[#334155] text-[#94A3B8] hover:text-[#F1F5F9] hover:border-[#6366F1]/50 transition-all"
        >
          Back to Dashboard
        </button>
      </motion.div>
    </div>
  );
}