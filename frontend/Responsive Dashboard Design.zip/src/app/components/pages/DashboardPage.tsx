import React, { useState } from "react";
import { useNavigate } from "react-router";
import { motion } from "motion/react";
import {
  Trophy, Code2, Users, Mic, Play, ChevronDown, BookOpen,
  Calendar, Clock, ArrowUpRight, Sparkles, GraduationCap, Star
} from "lucide-react";
import { StatCard } from "../ui/StatCard";
import { GlassCard } from "../ui/GlassCard";
import { Badge } from "../ui/Badge";
import { ProgressRing } from "../ui/ProgressRing";

const recentInterviews = [
  { id: 1, date: "Feb 28, 2026", type: "Technical", topic: "Data Structures", score: 88, duration: "45 min", status: "green" },
  { id: 2, date: "Feb 25, 2026", type: "HR", topic: "Leadership", score: 76, duration: "30 min", status: "yellow" },
  { id: 3, date: "Feb 22, 2026", type: "Technical", topic: "Algorithms", score: 92, duration: "50 min", status: "green" },
  { id: 4, date: "Feb 18, 2026", type: "HR", topic: "Communication", score: 71, duration: "25 min", status: "yellow" },
  { id: 5, date: "Feb 15, 2026", type: "Technical", topic: "System Design", score: 85, duration: "60 min", status: "green" },
];

const topics = ["Data Structures", "Algorithms", "System Design", "Database", "OS Concepts", "Object-Oriented Design"];
const difficulties = ["Easy", "Medium", "Hard"];
const questionCounts = ["5", "8", "10", "15"];

function ScoreBadge({ score }: { score: number }) {
  const color = score >= 85 ? "#22C55E" : score >= 70 ? "#F59E0B" : "#EF4444";
  return (
    <span
      style={{ fontSize: "0.78rem", fontWeight: 700, color, backgroundColor: `${color}20`, borderColor: `${color}40` }}
      className="px-2 py-0.5 rounded-md border"
    >
      {score}
    </span>
  );
}

export function DashboardPage() {
  const navigate = useNavigate();
  const [topic, setTopic] = useState("Data Structures");
  const [difficulty, setDifficulty] = useState("Medium");
  const [numQuestions, setNumQuestions] = useState("10");
  const [interviewType, setInterviewType] = useState<"technical" | "hr">("technical");

  const stats = [
    { label: "Avg Interview Score", value: "84", icon: Trophy, iconColor: "#F59E0B", iconBg: "rgba(245,158,11,0.15)", progress: 84, progressColor: "#F59E0B", trend: 5, subtitle: "Out of 100" },
    { label: "Technical Score", value: "88", icon: Code2, iconColor: "#6366F1", iconBg: "rgba(99,102,241,0.15)", progress: 88, progressColor: "#6366F1", trend: 7, subtitle: "Out of 100" },
    { label: "HR Score", value: "79", icon: Users, iconColor: "#22C55E", iconBg: "rgba(34,197,94,0.15)", progress: 79, progressColor: "#22C55E", trend: 3, subtitle: "Out of 100" },
    { label: "Confidence Score", value: "76", icon: Mic, iconColor: "#EC4899", iconBg: "rgba(236,72,153,0.15)", progress: 76, progressColor: "#EC4899", trend: -2, subtitle: "Out of 100" },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 style={{ fontSize: "1.6rem", fontWeight: 800 }} className="text-[#F1F5F9]">
            Welcome back, Aryan 👋
          </h1>
          <p style={{ fontSize: "0.875rem" }} className="text-[#94A3B8] mt-1">
            You have completed 12 interviews. Keep pushing!
          </p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#1E293B] border border-[#334155]">
          <Calendar size={14} className="text-[#94A3B8]" />
          <span style={{ fontSize: "0.78rem" }} className="text-[#94A3B8]">March 2026</span>
        </div>
      </div>

      {/* Profile + Stats row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Profile Card */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
          <GlassCard className="p-6 flex flex-col items-center gap-4 h-full">
            <div className="relative">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#6366F1] to-[#22C55E] flex items-center justify-center">
                <span style={{ fontSize: "1.8rem", fontWeight: 800 }} className="text-white">A</span>
              </div>
              <div className="absolute -bottom-1.5 -right-1.5 w-6 h-6 rounded-full bg-[#22C55E] border-2 border-[#0F172A] flex items-center justify-center">
                <Star size={10} className="text-white fill-white" />
              </div>
            </div>

            <div className="text-center">
              <p style={{ fontSize: "1.1rem", fontWeight: 700 }} className="text-[#F1F5F9]">Aryan Sharma</p>
              <p style={{ fontSize: "0.8rem" }} className="text-[#94A3B8] mt-0.5">Computer Science Engineering</p>
              <div className="flex items-center justify-center gap-1.5 mt-2">
                <GraduationCap size={13} className="text-[#6366F1]" />
                <span style={{ fontSize: "0.75rem" }} className="text-[#94A3B8]">Final Year · IIT Delhi</span>
              </div>
            </div>

            <div className="w-full h-px bg-[#334155]" />

            <div className="w-full grid grid-cols-2 gap-3">
              {[
                { label: "Interviews", value: "12", icon: BookOpen },
                { label: "Avg Score", value: "84", icon: Trophy },
              ].map(({ label, value, icon: Icon }) => (
                <div key={label} className="flex flex-col items-center gap-1 p-3 rounded-xl bg-[#0F172A] border border-[#334155]">
                  <Icon size={15} className="text-[#6366F1]" />
                  <span style={{ fontSize: "1.1rem", fontWeight: 700 }} className="text-[#F1F5F9]">{value}</span>
                  <span style={{ fontSize: "0.7rem" }} className="text-[#94A3B8]">{label}</span>
                </div>
              ))}
            </div>

            <div className="flex items-center gap-1.5">
              <Badge variant="purple">CSE</Badge>
              <Badge variant="green">Active</Badge>
              <Badge variant="blue">Year 4</Badge>
            </div>
          </GlassCard>
        </motion.div>

        {/* Score ring + Stats */}
        <motion.div
          className="md:col-span-2 flex flex-col gap-5"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
        >
          {/* Overall score */}
          <GlassCard className="p-6">
            <div className="flex flex-col sm:flex-row items-center gap-6">
              <ProgressRing value={84} size={130} strokeWidth={10} color="#6366F1" label="Overall Score" sublabel="/ 100" />
              <div className="flex-1 flex flex-col gap-3 w-full">
                <p style={{ fontSize: "0.85rem", fontWeight: 600 }} className="text-[#94A3B8] uppercase tracking-wider">Performance Breakdown</p>
                {[
                  { label: "Technical", val: 88, color: "#6366F1" },
                  { label: "HR / Behavioral", val: 79, color: "#22C55E" },
                  { label: "Voice Confidence", val: 76, color: "#F59E0B" },
                  { label: "Facial Expression", val: 82, color: "#EC4899" },
                ].map(({ label, val, color }) => (
                  <div key={label} className="flex items-center gap-3">
                    <span style={{ fontSize: "0.78rem" }} className="text-[#94A3B8] w-32 flex-shrink-0">{label}</span>
                    <div className="flex-1 bg-[#0F172A] rounded-full h-2">
                      <div className="h-2 rounded-full transition-all duration-700" style={{ width: `${val}%`, backgroundColor: color }} />
                    </div>
                    <span style={{ fontSize: "0.78rem", fontWeight: 700 }} className="text-[#F1F5F9] w-8 text-right">{val}</span>
                  </div>
                ))}
              </div>
            </div>
          </GlassCard>

          {/* Stat cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {stats.map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.2 + i * 0.05 }}
              >
                <StatCard {...stat} />
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Start Interview Section */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
        <GlassCard className="p-6">
          <div className="flex items-center gap-2 mb-6">
            <Sparkles size={18} className="text-[#6366F1]" />
            <h2 style={{ fontSize: "1rem", fontWeight: 700 }} className="text-[#F1F5F9]">Start New Interview</h2>
          </div>

          {/* Type toggle */}
          <div className="flex gap-3 mb-6 flex-wrap">
            {[
              { id: "technical", label: "Technical Interview", icon: Code2 },
              { id: "hr", label: "HR Interview", icon: Users },
            ].map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setInterviewType(id as typeof interviewType)}
                style={{ fontSize: "0.875rem", fontWeight: 600 }}
                className={`flex items-center gap-2 px-5 py-2.5 rounded-xl border transition-all duration-200 ${
                  interviewType === id
                    ? "bg-[#6366F1] border-[#6366F1] text-white"
                    : "border-[#334155] text-[#94A3B8] hover:border-[#6366F1]/50 hover:text-[#F1F5F9]"
                }`}
              >
                <Icon size={17} />
                {label}
              </button>
            ))}
          </div>

          {/* Options */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
            {/* Topic */}
            <div>
              <label style={{ fontSize: "0.78rem", fontWeight: 600 }} className="block text-[#94A3B8] mb-1.5 uppercase tracking-wider">Topic</label>
              <div className="relative">
                <select
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  style={{ fontSize: "0.875rem" }}
                  className="w-full px-4 py-2.5 rounded-xl bg-[#0F172A] border border-[#334155] text-[#F1F5F9] appearance-none focus:outline-none focus:border-[#6366F1] transition-colors"
                >
                  {topics.map((t) => <option key={t} value={t}>{t}</option>)}
                </select>
                <ChevronDown size={15} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#94A3B8] pointer-events-none" />
              </div>
            </div>

            {/* Difficulty */}
            <div>
              <label style={{ fontSize: "0.78rem", fontWeight: 600 }} className="block text-[#94A3B8] mb-1.5 uppercase tracking-wider">Difficulty</label>
              <div className="flex gap-2">
                {difficulties.map((d) => (
                  <button
                    key={d}
                    onClick={() => setDifficulty(d)}
                    style={{ fontSize: "0.78rem", fontWeight: 600 }}
                    className={`flex-1 py-2.5 rounded-xl border transition-all ${
                      difficulty === d
                        ? d === "Easy"
                          ? "bg-[#22C55E]/20 border-[#22C55E]/50 text-[#22C55E]"
                          : d === "Medium"
                          ? "bg-[#F59E0B]/20 border-[#F59E0B]/50 text-[#F59E0B]"
                          : "bg-red-500/20 border-red-500/50 text-red-400"
                        : "border-[#334155] text-[#94A3B8] hover:border-[#6366F1]/30"
                    }`}
                  >
                    {d}
                  </button>
                ))}
              </div>
            </div>

            {/* Number of questions */}
            <div>
              <label style={{ fontSize: "0.78rem", fontWeight: 600 }} className="block text-[#94A3B8] mb-1.5 uppercase tracking-wider">Questions</label>
              <div className="flex gap-2">
                {questionCounts.map((n) => (
                  <button
                    key={n}
                    onClick={() => setNumQuestions(n)}
                    style={{ fontSize: "0.85rem", fontWeight: 600 }}
                    className={`flex-1 py-2.5 rounded-xl border transition-all ${
                      numQuestions === n
                        ? "bg-[#6366F1]/20 border-[#6366F1]/50 text-[#6366F1]"
                        : "border-[#334155] text-[#94A3B8] hover:border-[#6366F1]/30"
                    }`}
                  >
                    {n}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Start button */}
          <button
            onClick={() => navigate("/interview")}
            className="flex items-center gap-2.5 px-8 py-3.5 rounded-xl text-white hover:scale-105 transition-transform"
            style={{ background: "linear-gradient(135deg, #6366F1, #4F46E5)", fontSize: "0.95rem", fontWeight: 700 }}
          >
            <Play size={18} />
            Launch {interviewType === "technical" ? "Technical" : "HR"} Interview · {numQuestions} Questions
          </button>
        </GlassCard>
      </motion.div>

      {/* Recent Interviews Table */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
        <GlassCard>
          <div className="flex items-center justify-between p-6 border-b border-[#334155]">
            <div className="flex items-center gap-2">
              <Clock size={18} className="text-[#6366F1]" />
              <h2 style={{ fontSize: "1rem", fontWeight: 700 }} className="text-[#F1F5F9]">Recent Interviews</h2>
            </div>
            <button
              onClick={() => navigate("/app/analytics")}
              style={{ fontSize: "0.78rem", fontWeight: 600 }}
              className="flex items-center gap-1.5 text-[#6366F1] hover:text-[#818CF8] transition-colors"
            >
              View All <ArrowUpRight size={14} />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#334155]">
                  {["Date", "Type", "Topic", "Score", "Duration", ""].map((h) => (
                    <th key={h} style={{ fontSize: "0.72rem", fontWeight: 600 }} className="text-left text-[#94A3B8] uppercase tracking-wider px-6 py-3">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {recentInterviews.map((row, i) => (
                  <tr key={row.id} className={`border-b border-[#334155]/50 hover:bg-[#1E293B]/50 transition-colors ${i === recentInterviews.length - 1 ? "border-b-0" : ""}`}>
                    <td className="px-6 py-4">
                      <span style={{ fontSize: "0.82rem" }} className="text-[#94A3B8]">{row.date}</span>
                    </td>
                    <td className="px-6 py-4">
                      <Badge variant={row.type === "Technical" ? "purple" : "green"}>{row.type}</Badge>
                    </td>
                    <td className="px-6 py-4">
                      <span style={{ fontSize: "0.82rem", fontWeight: 500 }} className="text-[#F1F5F9]">{row.topic}</span>
                    </td>
                    <td className="px-6 py-4">
                      <ScoreBadge score={row.score} />
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-1.5">
                        <Clock size={13} className="text-[#94A3B8]" />
                        <span style={{ fontSize: "0.82rem" }} className="text-[#94A3B8]">{row.duration}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <button
                        onClick={() => navigate("/app/results")}
                        style={{ fontSize: "0.75rem", fontWeight: 600 }}
                        className="text-[#6366F1] hover:text-[#818CF8] flex items-center gap-1 transition-colors"
                      >
                        Review <ArrowUpRight size={12} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </GlassCard>
      </motion.div>
    </div>
  );
}