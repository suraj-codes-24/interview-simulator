import React, { useState } from "react";
import { motion } from "motion/react";
import {
  LineChart, Line, AreaChart, Area, BarChart, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, ResponsiveContainer, Cell,
  RadarChart, Radar, PolarGrid, PolarAngleAxis, Legend
} from "recharts";
import { GlassCard } from "../ui/GlassCard";
import { Badge } from "../ui/Badge";
import { TrendingUp, BarChart3, Target, Filter, ChevronDown, Calendar } from "lucide-react";

const monthlyData = [
  { month: "Jan", technical: 72, hr: 68, overall: 70 },
  { month: "Feb", technical: 76, hr: 71, overall: 73 },
  { month: "Mar", technical: 78, hr: 75, overall: 76 },
  { month: "Apr", technical: 82, hr: 78, overall: 80 },
  { month: "May", technical: 79, hr: 80, overall: 79 },
  { month: "Jun", technical: 85, hr: 77, overall: 81 },
  { month: "Jul", technical: 88, hr: 82, overall: 85 },
  { month: "Aug", technical: 91, hr: 85, overall: 88 },
  { month: "Sep", technical: 87, hr: 83, overall: 85 },
  { month: "Oct", technical: 92, hr: 86, overall: 89 },
  { month: "Nov", technical: 89, hr: 88, overall: 88 },
  { month: "Dec", technical: 94, hr: 90, overall: 92 },
];

const radarData = [
  { subject: "Technical", A: 92, fullMark: 100 },
  { subject: "Communication", A: 80, fullMark: 100 },
  { subject: "Problem Solving", A: 88, fullMark: 100 },
  { subject: "Confidence", A: 76, fullMark: 100 },
  { subject: "Clarity", A: 84, fullMark: 100 },
  { subject: "Time Mgmt", A: 71, fullMark: 100 },
];

const topicData = [
  { topic: "Data Structures", score: 92, count: 4 },
  { topic: "Algorithms", score: 88, count: 3 },
  { topic: "System Design", score: 79, count: 2 },
  { topic: "Databases", score: 71, count: 2 },
  { topic: "OS Concepts", score: 65, count: 1 },
  { topic: "Leadership", score: 85, count: 3 },
  { topic: "Communication", score: 78, count: 2 },
];

const historyData = [
  { date: "Feb 15", score: 85, type: "Technical" },
  { date: "Feb 18", score: 71, type: "HR" },
  { date: "Feb 22", score: 92, type: "Technical" },
  { date: "Feb 25", score: 76, type: "HR" },
  { date: "Feb 28", score: 88, type: "Technical" },
  { date: "Mar 2", score: 82, type: "HR" },
  { date: "Mar 6", score: 94, type: "Technical" },
];

const tooltipStyle = {
  contentStyle: { backgroundColor: "#1E293B", border: "1px solid #334155", borderRadius: "12px", fontSize: "0.75rem" },
  labelStyle: { color: "#94A3B8" },
  itemStyle: { color: "#F1F5F9" },
};

// Heatmap cell helper
function getHeatColor(score: number) {
  if (score >= 90) return "#22C55E";
  if (score >= 80) return "#6366F1";
  if (score >= 70) return "#F59E0B";
  return "#EF4444";
}

function FilterSelect({ label, options, value, onChange }: { label: string; options: string[]; value: string; onChange: (v: string) => void }) {
  return (
    <div className="relative">
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        style={{ fontSize: "0.8rem" }}
        className="pl-3 pr-8 py-2 rounded-xl bg-[#1E293B] border border-[#334155] text-[#F1F5F9] appearance-none focus:outline-none focus:border-[#6366F1] transition-colors"
      >
        <option value="">{label}</option>
        {options.map((o) => <option key={o} value={o}>{o}</option>)}
      </select>
      <ChevronDown size={13} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#94A3B8] pointer-events-none" />
    </div>
  );
}

export function AnalyticsPage() {
  const [typeFilter, setTypeFilter] = useState("");
  const [topicFilter, setTopicFilter] = useState("");
  const [diffFilter, setDiffFilter] = useState("");

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 style={{ fontSize: "1.6rem", fontWeight: 800 }} className="text-[#F1F5F9]">Analytics</h1>
          <p style={{ fontSize: "0.875rem" }} className="text-[#94A3B8] mt-1">Track your performance trends and identify areas for growth.</p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#1E293B] border border-[#334155]">
          <Calendar size={14} className="text-[#94A3B8]" />
          <span style={{ fontSize: "0.78rem" }} className="text-[#94A3B8]">Last 12 Months</span>
        </div>
      </div>

      {/* Filters */}
      <GlassCard className="px-5 py-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <Filter size={15} className="text-[#6366F1]" />
            <span style={{ fontSize: "0.8rem", fontWeight: 600 }} className="text-[#94A3B8]">Filters:</span>
          </div>
          <FilterSelect label="All Types" options={["Technical", "HR"]} value={typeFilter} onChange={setTypeFilter} />
          <FilterSelect label="All Topics" options={["Data Structures", "Algorithms", "System Design", "Leadership"]} value={topicFilter} onChange={setTopicFilter} />
          <FilterSelect label="All Difficulties" options={["Easy", "Medium", "Hard"]} value={diffFilter} onChange={setDiffFilter} />
          {(typeFilter || topicFilter || diffFilter) && (
            <button
              onClick={() => { setTypeFilter(""); setTopicFilter(""); setDiffFilter(""); }}
              style={{ fontSize: "0.75rem", fontWeight: 600 }}
              className="text-[#6366F1] hover:text-[#818CF8] transition-colors"
            >
              Clear all
            </button>
          )}
        </div>
      </GlassCard>

      {/* Summary stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Total Interviews", value: "12", delta: "+3 this month", color: "#6366F1" },
          { label: "Best Score", value: "94", delta: "↑ 6 from last month", color: "#22C55E" },
          { label: "Avg Score", value: "84", delta: "↑ 5% improvement", color: "#F59E0B" },
          { label: "Hours Practiced", value: "8.5h", delta: "Over 12 sessions", color: "#EC4899" },
        ].map(({ label, value, delta, color }) => (
          <GlassCard key={label} className="p-5">
            <p style={{ fontSize: "0.72rem", fontWeight: 600 }} className="text-[#94A3B8] uppercase tracking-wider mb-1">{label}</p>
            <p style={{ fontSize: "1.8rem", fontWeight: 800, color }} className="mb-1">{value}</p>
            <p style={{ fontSize: "0.72rem" }} className="text-[#94A3B8]">{delta}</p>
          </GlassCard>
        ))}
      </div>

      {/* Score Progression */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
        <GlassCard className="p-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
            <div className="flex items-center gap-2">
              <TrendingUp size={18} className="text-[#6366F1]" />
              <h3 style={{ fontSize: "0.95rem", fontWeight: 700 }} className="text-[#F1F5F9]">Score Progression (2026)</h3>
            </div>
            <div className="flex items-center gap-4">
              {[
                { label: "Technical", color: "#6366F1" },
                { label: "HR", color: "#22C55E" },
                { label: "Overall", color: "#F59E0B" },
              ].map(({ label, color }) => (
                <div key={label} className="flex items-center gap-1.5">
                  <div className="w-3 h-0.5 rounded" style={{ backgroundColor: color }} />
                  <span style={{ fontSize: "0.72rem" }} className="text-[#94A3B8]">{label}</span>
                </div>
              ))}
            </div>
          </div>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={monthlyData}>
              <defs>
                {[
                  { id: "technical", color: "#6366F1" },
                  { id: "hr", color: "#22C55E" },
                  { id: "overall", color: "#F59E0B" },
                ].map(({ id, color }) => (
                  <linearGradient key={id} id={`grad-${id}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={color} stopOpacity={0.25} />
                    <stop offset="95%" stopColor={color} stopOpacity={0} />
                  </linearGradient>
                ))}
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" vertical={false} />
              <XAxis dataKey="month" tick={{ fill: "#94A3B8", fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis domain={[55, 100]} tick={{ fill: "#94A3B8", fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip {...tooltipStyle} />
              <Area type="monotone" dataKey="technical" stroke="#6366F1" strokeWidth={2} fill="url(#grad-technical)" dot={false} />
              <Area type="monotone" dataKey="hr" stroke="#22C55E" strokeWidth={2} fill="url(#grad-hr)" dot={false} />
              <Area type="monotone" dataKey="overall" stroke="#F59E0B" strokeWidth={2} fill="url(#grad-overall)" dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </GlassCard>
      </motion.div>

      {/* Radar + Topic Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Skills Radar */}
        <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}>
          <GlassCard className="p-6 h-full">
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-2">
                <Target size={18} className="text-[#6366F1]" />
                <h3 style={{ fontSize: "0.95rem", fontWeight: 700 }} className="text-[#F1F5F9]">Skills Radar</h3>
              </div>
              <Badge variant="purple">Cumulative</Badge>
            </div>
            <ResponsiveContainer width="100%" height={280}>
              <RadarChart data={radarData} cx="50%" cy="50%" outerRadius="70%">
                <PolarGrid stroke="#1E293B" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: "#94A3B8", fontSize: 11 }} />
                <Radar name="You" dataKey="A" stroke="#6366F1" fill="#6366F1" fillOpacity={0.3} strokeWidth={2} dot={{ fill: "#6366F1", r: 3 }} />
                <Legend
                  formatter={(value) => <span style={{ color: "#94A3B8", fontSize: "0.75rem" }}>{value}</span>}
                />
              </RadarChart>
            </ResponsiveContainer>
          </GlassCard>
        </motion.div>

        {/* Topic Weakness Heatmap */}
        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }}>
          <GlassCard className="p-6 h-full">
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-2">
                <BarChart3 size={18} className="text-[#6366F1]" />
                <h3 style={{ fontSize: "0.95rem", fontWeight: 700 }} className="text-[#F1F5F9]">Topic Performance</h3>
              </div>
              <Badge variant="default">Heatmap</Badge>
            </div>
            <div className="flex flex-col gap-2.5">
              {topicData.map(({ topic, score, count }) => (
                <div key={topic} className="flex items-center gap-3">
                  <span style={{ fontSize: "0.78rem" }} className="text-[#94A3B8] w-32 flex-shrink-0">{topic}</span>
                  <div className="flex-1 flex gap-1.5">
                    {[...Array(count)].map((_, i) => (
                      <div
                        key={i}
                        className="flex-1 h-7 rounded-lg flex items-center justify-center"
                        style={{ backgroundColor: `${getHeatColor(score)}20`, border: `1px solid ${getHeatColor(score)}40` }}
                      >
                        <span style={{ fontSize: "0.68rem", fontWeight: 700, color: getHeatColor(score) }}>{score}</span>
                      </div>
                    ))}
                  </div>
                  <span style={{ fontSize: "0.72rem", fontWeight: 700, color: getHeatColor(score) }} className="w-8 text-right">
                    {score}
                  </span>
                </div>
              ))}
            </div>
            {/* Legend */}
            <div className="flex items-center gap-3 mt-5 pt-4 border-t border-[#334155]">
              <span style={{ fontSize: "0.68rem" }} className="text-[#94A3B8]">Legend:</span>
              {[
                { label: "≥90", color: "#22C55E" },
                { label: "≥80", color: "#6366F1" },
                { label: "≥70", color: "#F59E0B" },
                { label: "<70", color: "#EF4444" },
              ].map(({ label, color }) => (
                <div key={label} className="flex items-center gap-1">
                  <div className="w-3 h-3 rounded" style={{ backgroundColor: color }} />
                  <span style={{ fontSize: "0.68rem" }} className="text-[#94A3B8]">{label}</span>
                </div>
              ))}
            </div>
          </GlassCard>
        </motion.div>
      </div>

      {/* Interview History Graph */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
        <GlassCard className="p-6">
          <div className="flex items-center gap-2 mb-6">
            <BarChart3 size={18} className="text-[#6366F1]" />
            <h3 style={{ fontSize: "0.95rem", fontWeight: 700 }} className="text-[#F1F5F9]">Interview History</h3>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={historyData} barSize={36}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" vertical={false} />
              <XAxis dataKey="date" tick={{ fill: "#94A3B8", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis domain={[50, 100]} tick={{ fill: "#94A3B8", fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip
                {...tooltipStyle}
                cursor={{ fill: "rgba(99,102,241,0.08)" }}
                content={({ active, payload, label }) => {
                  if (!active || !payload?.length) return null;
                  const data = historyData.find(d => d.date === label);
                  return (
                    <div className="rounded-xl bg-[#1E293B] border border-[#334155] p-3">
                      <p style={{ fontSize: "0.72rem" }} className="text-[#94A3B8] mb-1">{label}</p>
                      <p style={{ fontSize: "0.85rem", fontWeight: 700 }} className="text-[#F1F5F9]">Score: {payload[0].value}</p>
                      {data && <p style={{ fontSize: "0.72rem" }} className="text-[#6366F1] mt-0.5">{data.type}</p>}
                    </div>
                  );
                }}
              />
              <Bar dataKey="score" radius={[6, 6, 0, 0]}>
                {historyData.map((entry, i) => (
                  <Cell
                    key={i}
                    fill={entry.type === "Technical" ? "#6366F1" : "#22C55E"}
                    opacity={0.85}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
          <div className="flex items-center gap-4 mt-4 pt-4 border-t border-[#334155]">
            {[
              { label: "Technical", color: "#6366F1" },
              { label: "HR", color: "#22C55E" },
            ].map(({ label, color }) => (
              <div key={label} className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded" style={{ backgroundColor: color }} />
                <span style={{ fontSize: "0.75rem" }} className="text-[#94A3B8]">{label}</span>
              </div>
            ))}
          </div>
        </GlassCard>
      </motion.div>
    </div>
  );
}
