import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { Brain, Mic, Keyboard, X, ChevronRight, Volume2, Eye, Smile, Shield, ArrowLeft, AlertCircle } from "lucide-react";
import { GlassCard } from "../ui/GlassCard";
import { Badge } from "../ui/Badge";

const questions = [
  "Explain the concept of a binary search tree and its time complexities for insertion, deletion, and search.",
  "What is the difference between a stack and a queue? Give real-world examples of each.",
  "Describe the Big O notation. How would you analyze the time complexity of a nested loop?",
  "What is dynamic programming? Explain with an example like the Fibonacci sequence.",
  "How does quicksort work? What is its average and worst-case time complexity?",
];

type Status = "asking" | "listening" | "evaluating";

const statusConfig: Record<Status, { label: string; color: string; bg: string }> = {
  asking: { label: "Asking Question", color: "#6366F1", bg: "rgba(99,102,241,0.15)" },
  listening: { label: "Listening...", color: "#22C55E", bg: "rgba(34,197,94,0.15)" },
  evaluating: { label: "Evaluating", color: "#F59E0B", bg: "rgba(245,158,11,0.15)" },
};

function Waveform({ active }: { active: boolean }) {
  const heights = [4, 8, 6, 12, 8, 14, 10, 7, 11, 9, 13, 7, 10, 8, 12, 5, 9, 7, 11, 6];
  return (
    <div className="flex items-center gap-0.5 h-10">
      {heights.map((h, i) => (
        <div
          key={i}
          className={`w-1 rounded-full transition-all ${active ? "waveform-bar" : ""}`}
          style={{
            height: active ? `${h * 2}px` : "4px",
            backgroundColor: active ? "#6366F1" : "#334155",
            animationDelay: `${i * 0.06}s`,
            animationDuration: `${0.4 + (i % 3) * 0.15}s`,
          }}
        />
      ))}
    </div>
  );
}

export function InterviewRoomPage() {
  const navigate = useNavigate();
  const [currentQ, setCurrentQ] = useState(0);
  const [status, setStatus] = useState<Status>("asking");
  const [answerMode, setAnswerMode] = useState<"voice" | "text">("voice");
  const [textAnswer, setTextAnswer] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [timeLeft, setTimeLeft] = useState(180);
  const [showEndModal, setShowEndModal] = useState(false);

  const total = questions.length;

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 0) { clearInterval(timer); return 0; }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [currentQ]);

  useEffect(() => {
    setTimeLeft(180);
  }, [currentQ]);

  const formatTime = (s: number) => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;

  const handleRecord = () => {
    if (!isRecording) {
      setIsRecording(true);
      setStatus("listening");
    } else {
      setIsRecording(false);
      setStatus("evaluating");
      setTimeout(() => setStatus("asking"), 2000);
    }
  };

  const handleNext = () => {
    if (currentQ < total - 1) {
      setCurrentQ(currentQ + 1);
      setTextAnswer("");
      setStatus("asking");
      setIsRecording(false);
    } else {
      navigate("/app/results");
    }
  };

  const progress = ((currentQ + 1) / total) * 100;

  return (
    <div className="min-h-screen bg-[#0F172A] flex flex-col" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Top bar */}
      <header className="border-b border-[#334155] bg-[#0F172A]/90 backdrop-blur-xl px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
        <button
          onClick={() => setShowEndModal(true)}
          className="flex items-center gap-1.5 text-[#94A3B8] hover:text-[#F1F5F9] transition-colors"
          style={{ fontSize: "0.8rem" }}
        >
          <ArrowLeft size={16} />
          Exit
        </button>

        {/* Progress */}
        <div className="flex-1 max-w-sm flex flex-col gap-1">
          <div className="flex items-center justify-between">
            <span style={{ fontSize: "0.72rem", fontWeight: 600 }} className="text-[#94A3B8]">
              Question {currentQ + 1} / {total}
            </span>
            <span style={{ fontSize: "0.72rem", fontWeight: 600 }} className={timeLeft < 30 ? "text-red-400" : "text-[#94A3B8]"}>
              ⏱ {formatTime(timeLeft)}
            </span>
          </div>
          <div className="w-full bg-[#1E293B] rounded-full h-1.5">
            <div
              className="h-1.5 rounded-full transition-all duration-500"
              style={{ width: `${progress}%`, background: "linear-gradient(90deg, #6366F1, #22C55E)" }}
            />
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Badge variant={status === "asking" ? "purple" : status === "listening" ? "green" : "yellow"}>
            {statusConfig[status].label}
          </Badge>
          <button
            onClick={() => setShowEndModal(true)}
            style={{ fontSize: "0.78rem", fontWeight: 600 }}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-red-500/40 bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-colors"
          >
            <X size={13} />
            End
          </button>
        </div>
      </header>

      <div className="flex-1 flex flex-col lg:flex-row gap-4 p-4 sm:p-6 overflow-hidden">
        {/* LEFT: AI Interviewer */}
        <motion.div
          className="lg:w-2/5"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.4 }}
        >
          <GlassCard className="h-full flex flex-col gap-5 p-6">
            {/* Avatar */}
            <div className="flex flex-col items-center gap-4">
              <div className="relative">
                <div
                  className="w-24 h-24 rounded-full flex items-center justify-center"
                  style={{ background: "linear-gradient(135deg, #6366F1, #818CF8)" }}
                >
                  <Brain size={40} className="text-white" />
                </div>
                {/* Rings */}
                {status === "asking" && (
                  <>
                    <div className="absolute inset-0 rounded-full border-2 border-[#6366F1]/40 pulse-ring" style={{ transform: "scale(1.2)" }} />
                    <div className="absolute inset-0 rounded-full border border-[#6366F1]/20 pulse-ring" style={{ transform: "scale(1.4)", animationDelay: "0.3s" }} />
                  </>
                )}
                <div
                  className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full border-2 border-[#0F172A] flex items-center justify-center"
                  style={{ backgroundColor: statusConfig[status].bg, borderColor: "#0F172A" }}
                >
                  <Volume2 size={13} color={statusConfig[status].color} />
                </div>
              </div>

              <div className="text-center">
                <p style={{ fontSize: "1rem", fontWeight: 700 }} className="text-[#F1F5F9]">Alex — AI Interviewer</p>
                <div
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full mt-1.5"
                  style={{ backgroundColor: statusConfig[status].bg }}
                >
                  <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ backgroundColor: statusConfig[status].color }} />
                  <span style={{ fontSize: "0.72rem", fontWeight: 600, color: statusConfig[status].color }}>
                    {statusConfig[status].label}
                  </span>
                </div>
              </div>
            </div>

            {/* Question */}
            <AnimatePresence mode="wait">
              <motion.div
                key={currentQ}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3 }}
                className="rounded-xl bg-[#0F172A] border border-[#334155] p-4 flex-1"
              >
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-5 h-5 rounded-full bg-[#6366F1]/20 flex items-center justify-center">
                    <span style={{ fontSize: "0.6rem", fontWeight: 700 }} className="text-[#818CF8]">Q{currentQ + 1}</span>
                  </div>
                  <span style={{ fontSize: "0.7rem", fontWeight: 600 }} className="text-[#94A3B8] uppercase tracking-wider">Technical · Algorithms</span>
                </div>
                <p style={{ fontSize: "0.92rem", lineHeight: 1.7 }} className="text-[#F1F5F9]">
                  "{questions[currentQ]}"
                </p>
              </motion.div>
            </AnimatePresence>

            {/* AI waveform */}
            <div className="flex items-center gap-3">
              <Volume2 size={15} className="text-[#6366F1] flex-shrink-0" />
              <Waveform active={status === "asking"} />
            </div>
          </GlassCard>
        </motion.div>

        {/* RIGHT: User Camera */}
        <motion.div
          className="lg:w-3/5"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
        >
          <GlassCard className="h-full flex flex-col gap-5 p-5">
            {/* Camera area */}
            <div className="relative flex-1 rounded-xl bg-[#0A0F1E] border border-[#334155] overflow-hidden min-h-48">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="w-16 h-16 rounded-full bg-[#1E293B] border border-[#334155] flex items-center justify-center mx-auto mb-3">
                    <Eye size={24} className="text-[#94A3B8]" />
                  </div>
                  <p style={{ fontSize: "0.82rem" }} className="text-[#94A3B8]">Camera Preview</p>
                  <p style={{ fontSize: "0.72rem" }} className="text-[#475569] mt-1">Allow camera access to enable facial analysis</p>
                </div>
              </div>

              {/* Corner accents */}
              {[["top-3 left-3", "border-t border-l"], ["top-3 right-3", "border-t border-r"], ["bottom-3 left-3", "border-b border-l"], ["bottom-3 right-3", "border-b border-r"]].map(([pos, border], i) => (
                <div key={i} className={`absolute ${pos} w-5 h-5 border-[#6366F1]/60 rounded-sm ${border}`} />
              ))}

              {/* REC badge */}
              <div className="absolute top-3 left-1/2 -translate-x-1/2 flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-red-500/80">
                <div className="w-2 h-2 rounded-full bg-white animate-pulse" />
                <span style={{ fontSize: "0.65rem", fontWeight: 700 }} className="text-white">REC</span>
              </div>
            </div>

            {/* Live indicators */}
            <div className="grid grid-cols-3 gap-3">
              {[
                { icon: Eye, label: "Eye Contact", value: 87, color: "#22C55E" },
                { icon: Shield, label: "Confidence", value: 73, color: "#6366F1" },
                { icon: Smile, label: "Emotion", value: "Calm", color: "#F59E0B", isText: true },
              ].map(({ icon: Icon, label, value, color, isText }) => (
                <div key={label} className="flex flex-col gap-2 p-3 rounded-xl bg-[#0F172A] border border-[#334155]">
                  <div className="flex items-center gap-1.5">
                    <Icon size={13} color={color} />
                    <span style={{ fontSize: "0.68rem", fontWeight: 600 }} className="text-[#94A3B8] uppercase tracking-wider">{label}</span>
                  </div>
                  {isText ? (
                    <span style={{ fontSize: "0.95rem", fontWeight: 700, color }}>{value}</span>
                  ) : (
                    <>
                      <span style={{ fontSize: "0.95rem", fontWeight: 700, color }}>{value}%</span>
                      <div className="w-full bg-[#1E293B] rounded-full h-1">
                        <div className="h-1 rounded-full" style={{ width: `${value}%`, backgroundColor: color }} />
                      </div>
                    </>
                  )}
                </div>
              ))}
            </div>

            {/* Answer section */}
            <div className="flex flex-col gap-3">
              {/* Mode toggle */}
              <div className="flex gap-2">
                {[
                  { mode: "voice", icon: Mic, label: "Record Voice" },
                  { mode: "text", icon: Keyboard, label: "Type Answer" },
                ].map(({ mode, icon: Icon, label }) => (
                  <button
                    key={mode}
                    onClick={() => setAnswerMode(mode as "voice" | "text")}
                    style={{ fontSize: "0.8rem", fontWeight: 600 }}
                    className={`flex items-center gap-2 px-4 py-2 rounded-xl border transition-all ${
                      answerMode === mode
                        ? "bg-[#6366F1]/20 border-[#6366F1]/50 text-[#818CF8]"
                        : "border-[#334155] text-[#94A3B8] hover:border-[#6366F1]/30"
                    }`}
                  >
                    <Icon size={15} />
                    {label}
                  </button>
                ))}
              </div>

              {/* Voice or text input */}
              {answerMode === "voice" ? (
                <div className="flex items-center gap-4 p-4 rounded-xl bg-[#0F172A] border border-[#334155]">
                  <button
                    onClick={handleRecord}
                    className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
                      isRecording
                        ? "bg-red-500 scale-110 glow-pulse"
                        : "bg-[#6366F1] hover:bg-[#4F46E5]"
                    }`}
                  >
                    <Mic size={20} className="text-white" />
                  </button>
                  <div className="flex-1">
                    <Waveform active={isRecording} />
                  </div>
                  {isRecording && (
                    <span style={{ fontSize: "0.72rem", fontWeight: 600 }} className="text-red-400 animate-pulse">● RECORDING</span>
                  )}
                </div>
              ) : (
                <textarea
                  value={textAnswer}
                  onChange={(e) => setTextAnswer(e.target.value)}
                  placeholder="Type your answer here..."
                  rows={3}
                  style={{ fontSize: "0.875rem", lineHeight: 1.6 }}
                  className="w-full px-4 py-3 rounded-xl bg-[#0F172A] border border-[#334155] text-[#F1F5F9] placeholder-[#475569] focus:outline-none focus:border-[#6366F1] transition-colors resize-none"
                />
              )}

              {/* Action buttons */}
              <div className="flex gap-3">
                <button
                  onClick={handleNext}
                  className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-white hover:scale-[1.02] transition-transform"
                  style={{ background: "linear-gradient(135deg, #6366F1, #4F46E5)", fontSize: "0.875rem", fontWeight: 700 }}
                >
                  {currentQ < total - 1 ? (
                    <><ChevronRight size={18} /> Next Question</>
                  ) : (
                    <><Shield size={18} /> Finish Interview</>
                  )}
                </button>
                <button
                  onClick={() => setShowEndModal(true)}
                  style={{ fontSize: "0.875rem", fontWeight: 600 }}
                  className="px-5 py-3 rounded-xl border border-red-500/40 bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-colors"
                >
                  End
                </button>
              </div>
            </div>
          </GlassCard>
        </motion.div>
      </div>

      {/* End Interview Modal */}
      <AnimatePresence>
        {showEndModal && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm px-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="w-full max-w-md rounded-2xl border border-[#334155] bg-[#1E293B] p-8 text-center"
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
            >
              <div className="w-14 h-14 rounded-2xl bg-red-500/20 flex items-center justify-center mx-auto mb-5">
                <AlertCircle size={28} className="text-red-400" />
              </div>
              <h3 style={{ fontSize: "1.2rem", fontWeight: 700 }} className="text-[#F1F5F9] mb-2">End Interview?</h3>
              <p style={{ fontSize: "0.875rem" }} className="text-[#94A3B8] mb-6">
                You have completed {currentQ + 1} of {total} questions. Your results will be saved and analyzed.
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowEndModal(false)}
                  style={{ fontSize: "0.875rem", fontWeight: 600 }}
                  className="flex-1 py-3 rounded-xl border border-[#334155] text-[#94A3B8] hover:text-[#F1F5F9] transition-colors"
                >
                  Continue
                </button>
                <button
                  onClick={() => navigate("/app/results")}
                  style={{ fontSize: "0.875rem", fontWeight: 600 }}
                  className="flex-1 py-3 rounded-xl bg-red-500 text-white hover:bg-red-600 transition-colors"
                >
                  End & View Results
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}