import React, { useState } from "react";
import { useNavigate } from "react-router";
import { motion } from "motion/react";
import { Brain, Eye, EyeOff, ArrowLeft, Zap, Shield, BarChart3, Mic } from "lucide-react";

const highlights = [
  { icon: Brain, text: "Multimodal AI analysis" },
  { icon: Mic, text: "Voice confidence scoring" },
  { icon: BarChart3, text: "Deep performance analytics" },
  { icon: Shield, text: "Enterprise-grade privacy" },
];

export function LoginPage() {
  const navigate = useNavigate();
  const [showPass, setShowPass] = useState(false);
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      navigate("/app");
    }, 1200);
  };

  return (
    <div className="min-h-screen bg-[#0F172A] flex" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Left Panel */}
      <div className="hidden lg:flex flex-1 flex-col justify-between p-12 relative overflow-hidden border-r border-[#334155]">
        {/* Gradient background */}
        <div className="absolute inset-0" style={{ background: "linear-gradient(135deg, #0F172A 0%, #1a1f3a 50%, #0F172A 100%)" }} />
        <div className="absolute top-20 left-20 w-80 h-80 rounded-full blur-3xl" style={{ background: "radial-gradient(ellipse, rgba(99,102,241,0.2) 0%, transparent 70%)" }} />
        <div className="absolute bottom-20 right-20 w-60 h-60 rounded-full blur-3xl" style={{ background: "radial-gradient(ellipse, rgba(34,197,94,0.15) 0%, transparent 70%)" }} />

        <div className="relative z-10">
          <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => navigate("/")}>
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#6366F1] to-[#818CF8] flex items-center justify-center">
              <Brain size={20} className="text-white" />
            </div>
            <span style={{ fontSize: "1.1rem", fontWeight: 700 }} className="text-[#F1F5F9]">InterviewAI</span>
          </div>
        </div>

        <div className="relative z-10 flex flex-col gap-8">
          {/* Large visual element */}
          <div className="w-full rounded-2xl border border-[#334155] bg-[#1E293B]/60 p-8 backdrop-blur-md float-element">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#6366F1] to-[#818CF8] flex items-center justify-center pulse-ring">
                <Brain size={28} className="text-white" />
              </div>
              <div>
                <p style={{ fontSize: "1rem", fontWeight: 700 }} className="text-[#F1F5F9]">Live AI Interview</p>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <div className="w-2 h-2 rounded-full bg-[#22C55E] animate-pulse" />
                  <span style={{ fontSize: "0.72rem" }} className="text-[#22C55E]">Session Active</span>
                </div>
              </div>
            </div>

            <div className="rounded-xl bg-[#0F172A] border border-[#334155] p-4 mb-4">
              <p style={{ fontSize: "0.8rem" }} className="text-[#94A3B8] mb-1">AI Interviewer</p>
              <p style={{ fontSize: "0.88rem" }} className="text-[#F1F5F9]">
                "Describe a time you demonstrated leadership in a challenging technical project."
              </p>
            </div>

            <div className="flex flex-col gap-2">
              {[
                { label: "Eye Contact", val: 87, color: "#22C55E" },
                { label: "Confidence", val: 73, color: "#6366F1" },
                { label: "Clarity", val: 91, color: "#F59E0B" },
              ].map(({ label, val, color }) => (
                <div key={label} className="flex items-center gap-3">
                  <span style={{ fontSize: "0.72rem" }} className="text-[#94A3B8] w-20">{label}</span>
                  <div className="flex-1 bg-[#0F172A] rounded-full h-1.5">
                    <div className="h-1.5 rounded-full transition-all" style={{ width: `${val}%`, backgroundColor: color }} />
                  </div>
                  <span style={{ fontSize: "0.72rem", fontWeight: 600 }} className="text-[#F1F5F9] w-8 text-right">{val}%</span>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {highlights.map(({ icon: Icon, text }) => (
              <div key={text} className="flex items-center gap-2.5 px-3 py-2.5 rounded-xl bg-[#1E293B]/60 border border-[#334155]">
                <Icon size={16} className="text-[#6366F1] flex-shrink-0" />
                <span style={{ fontSize: "0.78rem" }} className="text-[#94A3B8]">{text}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="relative z-10">
          <p style={{ fontSize: "0.75rem" }} className="text-[#94A3B8]">
            © 2026 InterviewAI · Privacy · Terms
          </p>
        </div>
      </div>

      {/* Right Panel – Auth Form */}
      <div className="flex-1 flex flex-col items-center justify-center px-4 sm:px-8 lg:px-16 py-12">
        <motion.div
          className="w-full max-w-md"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* Back to home on mobile */}
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-1.5 mb-8 text-[#94A3B8] hover:text-[#F1F5F9] transition-colors lg:hidden"
            style={{ fontSize: "0.8rem" }}
          >
            <ArrowLeft size={15} />
            Back to home
          </button>

          {/* Logo on mobile */}
          <div className="flex items-center gap-2 mb-8 lg:hidden">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#6366F1] to-[#818CF8] flex items-center justify-center">
              <Brain size={17} className="text-white" />
            </div>
            <span style={{ fontSize: "0.95rem", fontWeight: 700 }} className="text-[#F1F5F9]">InterviewAI</span>
          </div>

          {/* Toggle */}
          <div className="flex p-1 rounded-xl bg-[#1E293B] border border-[#334155] mb-8">
            {["Sign In", "Sign Up"].map((label) => (
              <button
                key={label}
                onClick={() => setIsLogin(label === "Sign In")}
                style={{ fontSize: "0.875rem", fontWeight: 600 }}
                className={`flex-1 py-2 rounded-lg transition-all duration-200 ${
                  (isLogin && label === "Sign In") || (!isLogin && label === "Sign Up")
                    ? "bg-[#6366F1] text-white"
                    : "text-[#94A3B8] hover:text-[#F1F5F9]"
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="mb-8">
            <h1 style={{ fontSize: "1.75rem", fontWeight: 800 }} className="text-[#F1F5F9] mb-2">
              {isLogin ? "Welcome back" : "Create account"}
            </h1>
            <p style={{ fontSize: "0.875rem" }} className="text-[#94A3B8]">
              {isLogin
                ? "Sign in to continue your interview prep journey."
                : "Start your AI-powered interview training today."}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            {!isLogin && (
              <div>
                <label style={{ fontSize: "0.8rem", fontWeight: 600 }} className="block text-[#94A3B8] mb-1.5">Full Name</label>
                <input
                  type="text"
                  placeholder="Aryan Sharma"
                  style={{ fontSize: "0.875rem" }}
                  className="w-full px-4 py-3 rounded-xl bg-[#1E293B] border border-[#334155] text-[#F1F5F9] placeholder-[#475569] focus:outline-none focus:border-[#6366F1] transition-colors"
                />
              </div>
            )}

            <div>
              <label style={{ fontSize: "0.8rem", fontWeight: 600 }} className="block text-[#94A3B8] mb-1.5">Email address</label>
              <input
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                style={{ fontSize: "0.875rem" }}
                className="w-full px-4 py-3 rounded-xl bg-[#1E293B] border border-[#334155] text-[#F1F5F9] placeholder-[#475569] focus:outline-none focus:border-[#6366F1] transition-colors"
              />
            </div>

            <div>
              <label style={{ fontSize: "0.8rem", fontWeight: 600 }} className="block text-[#94A3B8] mb-1.5">Password</label>
              <div className="relative">
                <input
                  type={showPass ? "text" : "password"}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  style={{ fontSize: "0.875rem" }}
                  className="w-full px-4 py-3 pr-12 rounded-xl bg-[#1E293B] border border-[#334155] text-[#F1F5F9] placeholder-[#475569] focus:outline-none focus:border-[#6366F1] transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#94A3B8] hover:text-[#F1F5F9]"
                >
                  {showPass ? <EyeOff size={17} /> : <Eye size={17} />}
                </button>
              </div>
            </div>

            {isLogin && (
              <div className="flex justify-end">
                <button type="button" style={{ fontSize: "0.78rem" }} className="text-[#6366F1] hover:text-[#818CF8] transition-colors">
                  Forgot password?
                </button>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl text-white transition-all duration-200 hover:scale-[1.02] disabled:opacity-70 disabled:scale-100 mt-1"
              style={{ background: "linear-gradient(135deg, #6366F1, #4F46E5)", fontSize: "0.95rem", fontWeight: 600 }}
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                  </svg>
                  {isLogin ? "Signing in..." : "Creating account..."}
                </span>
              ) : isLogin ? "Sign In" : "Create Account"}
            </button>
          </form>

          <div className="flex items-center gap-3 my-5">
            <div className="flex-1 h-px bg-[#334155]" />
            <span style={{ fontSize: "0.75rem" }} className="text-[#475569]">or continue with</span>
            <div className="flex-1 h-px bg-[#334155]" />
          </div>

          <button
            onClick={() => navigate("/app")}
            style={{ fontSize: "0.875rem", fontWeight: 500 }}
            className="w-full py-3 rounded-xl border border-[#334155] bg-[#1E293B] text-[#F1F5F9] hover:border-[#6366F1]/50 transition-colors flex items-center justify-center gap-3"
          >
            <svg width="18" height="18" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
            </svg>
            Continue with Google
          </button>

          <p style={{ fontSize: "0.8rem" }} className="text-center text-[#94A3B8] mt-6">
            {isLogin ? "Don't have an account? " : "Already have an account? "}
            <button
              onClick={() => setIsLogin(!isLogin)}
              style={{ fontWeight: 600 }}
              className="text-[#6366F1] hover:text-[#818CF8] transition-colors"
            >
              {isLogin ? "Create account" : "Sign in"}
            </button>
          </p>
        </motion.div>
      </div>
    </div>
  );
}