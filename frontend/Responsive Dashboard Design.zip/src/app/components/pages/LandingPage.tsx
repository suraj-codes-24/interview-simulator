import React, { useState } from "react";
import { useNavigate } from "react-router";
import { motion } from "motion/react";
import {
  Brain, Play, Mic, Eye, Code2, Users, ChevronRight,
  Twitter, Github, Linkedin, ArrowRight, Star, Zap, Shield, BarChart3, Menu, X
} from "lucide-react";
import { GlassCard } from "../ui/GlassCard";

const features = [
  {
    icon: Code2,
    title: "AI Technical Interviews",
    desc: "Practice DSA, system design, and coding challenges with an AI that adapts to your skill level in real time.",
    color: "#6366F1",
    bg: "rgba(99,102,241,0.12)",
  },
  {
    icon: Users,
    title: "HR Behavioral Interviews",
    desc: "Master STAR-based behavioral questions with personalized coaching and detailed feedback loops.",
    color: "#22C55E",
    bg: "rgba(34,197,94,0.12)",
  },
  {
    icon: Mic,
    title: "Voice Confidence Analysis",
    desc: "Real-time analysis of your speaking pace, clarity, filler words, and tonal confidence.",
    color: "#F59E0B",
    bg: "rgba(245,158,11,0.12)",
  },
  {
    icon: Eye,
    title: "Facial Expression Analysis",
    desc: "Computer vision tracks eye contact, posture, and micro-expressions to improve non-verbal communication.",
    color: "#EC4899",
    bg: "rgba(236,72,153,0.12)",
  },
];

const steps = [
  { step: "01", title: "Start Interview", desc: "Choose interview type, topic, and difficulty level to begin your session.", icon: Play },
  { step: "02", title: "Answer Questions", desc: "Respond via voice or text while our AI monitors your performance live.", icon: Mic },
  { step: "03", title: "AI Evaluates", desc: "Our multimodal AI analyzes content, voice, and facial expressions simultaneously.", icon: Brain },
  { step: "04", title: "Get Analytics", desc: "Receive a comprehensive report with scores, feedback, and improvement roadmap.", icon: BarChart3 },
];

const stats = [
  { value: "50K+", label: "Interviews Completed" },
  { value: "94%", label: "Placement Rate" },
  { value: "4.9★", label: "Average Rating" },
  { value: "120+", label: "Partner Companies" },
];

function MockInterviewUI() {
  return (
    <div className="relative w-full max-w-2xl mx-auto">
      {/* Glow behind */}
      <div className="absolute inset-0 rounded-3xl blur-3xl" style={{ background: "radial-gradient(ellipse at center, rgba(99,102,241,0.25) 0%, transparent 70%)" }} />

      <GlassCard className="p-1 relative z-10">
        {/* Top bar */}
        <div className="flex items-center gap-2 px-4 py-3 border-b border-[#334155]">
          <div className="flex gap-1.5">
            <div className="w-3 h-3 rounded-full bg-red-500/80" />
            <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
            <div className="w-3 h-3 rounded-full bg-green-500/80" />
          </div>
          <div className="flex-1 flex justify-center">
            <div className="px-4 py-1 rounded-md bg-[#0F172A] border border-[#334155]">
              <span style={{ fontSize: "0.7rem" }} className="text-[#94A3B8]">interviewai.app — Live Session</span>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-[#22C55E] animate-pulse" />
            <span style={{ fontSize: "0.7rem" }} className="text-[#22C55E]">LIVE</span>
          </div>
        </div>

        {/* Interview panels */}
        <div className="flex gap-3 p-4">
          {/* AI Interviewer */}
          <div className="flex-1 rounded-xl bg-[#0F172A] border border-[#334155] p-4 flex flex-col items-center gap-3">
            <div className="relative">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#6366F1] to-[#818CF8] flex items-center justify-center pulse-ring">
                <Brain size={28} className="text-white" />
              </div>
              <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-[#22C55E] border-2 border-[#0F172A] flex items-center justify-center">
                <Mic size={9} className="text-white" />
              </div>
            </div>
            <div className="text-center">
              <p style={{ fontSize: "0.75rem", fontWeight: 600 }} className="text-[#F1F5F9]">AI Interviewer</p>
              <div className="flex items-center gap-1 justify-center mt-0.5">
                <div className="w-1.5 h-1.5 rounded-full bg-[#22C55E] animate-pulse" />
                <span style={{ fontSize: "0.65rem" }} className="text-[#22C55E]">Asking Question</span>
              </div>
            </div>
            <div className="w-full rounded-lg bg-[#1E293B] border border-[#334155] p-2">
              <p style={{ fontSize: "0.68rem" }} className="text-[#94A3B8] leading-relaxed">
                "Explain the time complexity of a binary search tree lookup operation..."
              </p>
            </div>
            {/* Waveform */}
            <div className="flex items-end gap-0.5 h-6">
              {[3,6,4,8,5,9,6,4,7,5,8,3,6,9,5].map((h, i) => (
                <div
                  key={i}
                  className="w-1 rounded-full bg-[#6366F1] waveform-bar"
                  style={{ height: `${h * 2}px`, animationDelay: `${i * 0.05}s` }}
                />
              ))}
            </div>
          </div>

          {/* User Camera */}
          <div className="flex-1 rounded-xl bg-[#0F172A] border border-[#334155] p-4 flex flex-col gap-3">
            <div className="rounded-lg overflow-hidden aspect-video bg-[#0A1020] border border-[#334155] relative">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="w-10 h-10 rounded-full bg-[#1E293B] flex items-center justify-center mx-auto mb-1">
                    <Users size={18} className="text-[#94A3B8]" />
                  </div>
                  <p style={{ fontSize: "0.65rem" }} className="text-[#94A3B8]">Camera Feed</p>
                </div>
              </div>
              <div className="absolute top-2 right-2 flex items-center gap-1 px-1.5 py-0.5 rounded-md bg-red-500/80">
                <div className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                <span style={{ fontSize: "0.6rem" }} className="text-white">REC</span>
              </div>
            </div>
            <div className="flex flex-col gap-1.5">
              {[
                { label: "Eye Contact", val: 87, color: "#22C55E" },
                { label: "Confidence", val: 72, color: "#6366F1" },
              ].map(({ label, val, color }) => (
                <div key={label} className="flex items-center gap-2">
                  <span style={{ fontSize: "0.65rem" }} className="text-[#94A3B8] w-16 flex-shrink-0">{label}</span>
                  <div className="flex-1 bg-[#1E293B] rounded-full h-1.5">
                    <div className="h-1.5 rounded-full" style={{ width: `${val}%`, backgroundColor: color }} />
                  </div>
                  <span style={{ fontSize: "0.65rem", fontWeight: 600 }} className="text-[#F1F5F9] w-6 text-right">{val}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Progress bar */}
        <div className="px-4 pb-4 flex items-center gap-3">
          <span style={{ fontSize: "0.7rem" }} className="text-[#94A3B8] flex-shrink-0">Q 2/5</span>
          <div className="flex-1 bg-[#0F172A] rounded-full h-1.5">
            <div className="h-1.5 rounded-full bg-gradient-to-r from-[#6366F1] to-[#818CF8]" style={{ width: "40%" }} />
          </div>
          <span style={{ fontSize: "0.7rem" }} className="text-[#94A3B8] flex-shrink-0">03:42</span>
        </div>
      </GlassCard>
    </div>
  );
}

export function LandingPage() {
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#0F172A]" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Navbar */}
      <header className="sticky top-0 z-50 border-b border-[#334155] bg-[#0F172A]/90 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#6366F1] to-[#818CF8] flex items-center justify-center">
                <Brain size={18} className="text-white" />
              </div>
              <span style={{ fontSize: "1rem", fontWeight: 700 }} className="text-[#F1F5F9]">InterviewAI</span>
            </div>
            <nav className="hidden md:flex items-center gap-6">
              {["Features", "How it Works", "Pricing"].map((item) => (
                <a key={item} href={`#${item.toLowerCase().replace(/\s+/g, "-")}`} style={{ fontSize: "0.875rem" }} className="text-[#94A3B8] hover:text-[#F1F5F9] transition-colors">
                  {item}
                </a>
              ))}
            </nav>
            <div className="hidden md:flex items-center gap-3">
              <button onClick={() => navigate("/login")} style={{ fontSize: "0.875rem", fontWeight: 500 }} className="text-[#94A3B8] hover:text-[#F1F5F9] transition-colors">
                Sign In
              </button>
              <button
                onClick={() => navigate("/app")}
                style={{ fontSize: "0.875rem", fontWeight: 600 }}
                className="px-4 py-2 rounded-lg bg-[#6366F1] text-white hover:bg-[#4F46E5] transition-colors"
              >
                Get Started
              </button>
            </div>
            <button onClick={() => setMobileOpen(!mobileOpen)} className="md:hidden text-[#94A3B8]">
              {mobileOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
        {mobileOpen && (
          <div className="md:hidden border-t border-[#334155] bg-[#0F172A] px-4 py-3 flex flex-col gap-3">
            {["Features", "How it Works", "Pricing"].map((item) => (
              <a key={item} href="#" style={{ fontSize: "0.875rem" }} className="text-[#94A3B8]">{item}</a>
            ))}
            <button onClick={() => navigate("/login")} style={{ fontSize: "0.875rem", fontWeight: 600 }} className="w-full py-2.5 rounded-lg bg-[#6366F1] text-white">
              Get Started Free
            </button>
          </div>
        )}
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden pt-20 pb-24 px-4 sm:px-6 lg:px-8">
        {/* Background gradients */}
        <div className="absolute top-0 left-1/4 w-96 h-96 rounded-full blur-3xl pointer-events-none" style={{ background: "radial-gradient(ellipse, rgba(99,102,241,0.15) 0%, transparent 70%)" }} />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 rounded-full blur-3xl pointer-events-none" style={{ background: "radial-gradient(ellipse, rgba(34,197,94,0.1) 0%, transparent 70%)" }} />

        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col lg:flex-row items-center gap-16">
            {/* Left: Text */}
            <motion.div
              className="flex-1 text-center lg:text-left"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#6366F1]/40 bg-[#6366F1]/10 mb-6">
                <Zap size={13} className="text-[#818CF8]" />
                <span style={{ fontSize: "0.75rem", fontWeight: 600 }} className="text-[#818CF8]">Multimodal AI — Voice + Vision + NLP</span>
              </div>

              <h1 style={{ fontSize: "clamp(2.5rem, 6vw, 4rem)", fontWeight: 800, lineHeight: 1.1 }} className="text-[#F1F5F9] mb-6">
                AI Interview{" "}
                <span style={{ background: "linear-gradient(135deg, #6366F1, #818CF8, #22C55E)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                  Simulator
                </span>
              </h1>

              <p style={{ fontSize: "1.125rem", lineHeight: 1.7 }} className="text-[#94A3B8] mb-8 max-w-xl mx-auto lg:mx-0">
                Practice technical and behavioral interviews with a real-time AI that analyzes your voice, facial expressions, and answers — and gives you actionable feedback to land your dream job.
              </p>

              <div className="flex flex-col sm:flex-row gap-3 justify-center lg:justify-start">
                <button
                  onClick={() => navigate("/interview")}
                  className="flex items-center justify-center gap-2 px-6 py-3 rounded-xl text-white transition-all duration-200 hover:scale-105"
                  style={{ background: "linear-gradient(135deg, #6366F1, #4F46E5)", fontSize: "0.95rem", fontWeight: 600 }}
                >
                  <Play size={18} />
                  Start Mock Interview
                </button>
                <button
                  onClick={() => navigate("/app")}
                  style={{ fontSize: "0.95rem", fontWeight: 500 }}
                  className="flex items-center justify-center gap-2 px-6 py-3 rounded-xl border border-[#334155] text-[#94A3B8] hover:text-[#F1F5F9] hover:border-[#6366F1]/50 transition-all"
                >
                  View Demo
                  <ChevronRight size={18} />
                </button>
              </div>

              {/* Social proof */}
              <div className="flex items-center gap-3 mt-8 justify-center lg:justify-start">
                <div className="flex -space-x-2">
                  {["#6366F1","#22C55E","#F59E0B","#EC4899"].map((color, i) => (
                    <div key={i} className="w-7 h-7 rounded-full border-2 border-[#0F172A] flex items-center justify-center" style={{ backgroundColor: color }}>
                      <Users size={10} className="text-white" />
                    </div>
                  ))}
                </div>
                <div>
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => <Star key={i} size={12} className="text-yellow-400 fill-yellow-400" />)}
                  </div>
                  <p style={{ fontSize: "0.72rem" }} className="text-[#94A3B8]">Trusted by 50,000+ candidates</p>
                </div>
              </div>
            </motion.div>

            {/* Right: Mock UI */}
            <motion.div
              className="flex-1 w-full"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <MockInterviewUI />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 border-y border-[#334155] bg-[#1E293B]/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map(({ value, label }) => (
              <div key={label} className="text-center">
                <p style={{ fontSize: "2rem", fontWeight: 800 }} className="text-[#F1F5F9]">{value}</p>
                <p style={{ fontSize: "0.8rem" }} className="text-[#94A3B8] mt-1">{label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-14">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#334155] bg-[#1E293B] mb-4">
              <Shield size={13} className="text-[#818CF8]" />
              <span style={{ fontSize: "0.72rem", fontWeight: 600 }} className="text-[#94A3B8] uppercase tracking-wider">Core Features</span>
            </div>
            <h2 style={{ fontSize: "clamp(1.8rem, 4vw, 2.5rem)", fontWeight: 700 }} className="text-[#F1F5F9] mb-4">
              Everything you need to{" "}
              <span style={{ color: "#6366F1" }}>ace any interview</span>
            </h2>
            <p style={{ fontSize: "1rem" }} className="text-[#94A3B8] max-w-xl mx-auto">
              Our AI-powered platform covers every dimension of interview performance, from technical depth to emotional intelligence.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map(({ icon: Icon, title, desc, color, bg }, i) => (
              <motion.div
                key={title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <GlassCard className="p-6 h-full flex flex-col gap-4 hover:scale-[1.02] transition-transform duration-200">
                  <div className="w-11 h-11 rounded-xl flex items-center justify-center" style={{ backgroundColor: bg }}>
                    <Icon size={22} color={color} />
                  </div>
                  <div>
                    <h3 style={{ fontSize: "0.95rem", fontWeight: 600 }} className="text-[#F1F5F9] mb-2">{title}</h3>
                    <p style={{ fontSize: "0.83rem", lineHeight: 1.6 }} className="text-[#94A3B8]">{desc}</p>
                  </div>
                  <div className="mt-auto">
                    <button style={{ fontSize: "0.78rem", fontWeight: 600, color }} className="flex items-center gap-1 hover:gap-2 transition-all">
                      Learn more <ArrowRight size={13} />
                    </button>
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section id="how-it-works" className="py-20 px-4 sm:px-6 lg:px-8 bg-[#1E293B]/20">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-14">
            <h2 style={{ fontSize: "clamp(1.8rem, 4vw, 2.5rem)", fontWeight: 700 }} className="text-[#F1F5F9] mb-4">
              How it Works
            </h2>
            <p style={{ fontSize: "1rem" }} className="text-[#94A3B8]">Four simple steps to transform your interview performance</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 relative">
            {/* Connector line on desktop */}
            <div className="hidden lg:block absolute top-12 left-1/4 right-1/4 h-px bg-gradient-to-r from-transparent via-[#334155] to-transparent" />

            {steps.map(({ step, title, desc, icon: Icon }, i) => (
              <motion.div
                key={step}
                className="flex flex-col items-center text-center gap-4"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
              >
                <div className="relative">
                  <div
                    className="w-16 h-16 rounded-2xl flex items-center justify-center border border-[#334155]"
                    style={{ background: "linear-gradient(135deg, #1E293B, #0F172A)" }}
                  >
                    <Icon size={26} className="text-[#6366F1]" />
                  </div>
                  <div
                    className="absolute -top-2 -right-2 w-6 h-6 rounded-full flex items-center justify-center border border-[#6366F1]/40"
                    style={{ backgroundColor: "#6366F1", fontSize: "0.65rem", fontWeight: 800 }}
                  >
                    <span className="text-white">{step}</span>
                  </div>
                </div>
                <div>
                  <h3 style={{ fontSize: "1rem", fontWeight: 600 }} className="text-[#F1F5F9] mb-2">{title}</h3>
                  <p style={{ fontSize: "0.83rem", lineHeight: 1.6 }} className="text-[#94A3B8]">{desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center">
          <div className="rounded-3xl border border-[#6366F1]/30 p-12 relative overflow-hidden"
            style={{ background: "linear-gradient(135deg, rgba(99,102,241,0.12), rgba(34,197,94,0.06))" }}>
            <div className="absolute inset-0 rounded-3xl" style={{ background: "radial-gradient(ellipse at center, rgba(99,102,241,0.15) 0%, transparent 70%)" }} />
            <div className="relative z-10">
              <h2 style={{ fontSize: "clamp(1.8rem, 4vw, 2.5rem)", fontWeight: 700 }} className="text-[#F1F5F9] mb-4">
                Ready to land your dream job?
              </h2>
              <p style={{ fontSize: "1rem" }} className="text-[#94A3B8] mb-8">
                Join 50,000+ candidates who improved their interview performance with AI.
              </p>
              <button
                onClick={() => navigate("/login")}
                className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl text-white hover:scale-105 transition-transform"
                style={{ background: "linear-gradient(135deg, #6366F1, #4F46E5)", fontSize: "1rem", fontWeight: 600 }}
              >
                Start Free Today
                <ArrowRight size={20} />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-[#334155] py-10 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-[#6366F1] to-[#818CF8] flex items-center justify-center">
                <Brain size={15} className="text-white" />
              </div>
              <span style={{ fontSize: "0.9rem", fontWeight: 700 }} className="text-[#F1F5F9]">InterviewAI</span>
            </div>
            <div className="flex items-center gap-6">
              {["Privacy", "Terms", "Blog", "Careers", "Support"].map((link) => (
                <a key={link} href="#" style={{ fontSize: "0.8rem" }} className="text-[#94A3B8] hover:text-[#F1F5F9] transition-colors">{link}</a>
              ))}
            </div>
            <div className="flex items-center gap-3">
              {[Twitter, Github, Linkedin].map((Icon, i) => (
                <button key={i} className="w-8 h-8 rounded-lg bg-[#1E293B] border border-[#334155] flex items-center justify-center text-[#94A3B8] hover:text-[#F1F5F9] hover:border-[#6366F1]/40 transition-colors">
                  <Icon size={15} />
                </button>
              ))}
            </div>
          </div>
          <p style={{ fontSize: "0.75rem" }} className="text-center text-[#94A3B8] mt-8">
            © 2026 InterviewAI. All rights reserved. Built with ♥ for aspiring engineers.
          </p>
        </div>
      </footer>
    </div>
  );
}