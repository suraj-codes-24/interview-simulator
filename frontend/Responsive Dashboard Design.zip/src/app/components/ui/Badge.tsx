import React from "react";

type BadgeVariant = "purple" | "green" | "yellow" | "red" | "blue" | "default";

interface BadgeProps {
  children: React.ReactNode;
  variant?: BadgeVariant;
  className?: string;
}

const variants: Record<BadgeVariant, string> = {
  purple: "bg-[#6366F1]/20 text-[#818CF8] border-[#6366F1]/30",
  green: "bg-[#22C55E]/20 text-[#4ADE80] border-[#22C55E]/30",
  yellow: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  red: "bg-red-500/20 text-red-400 border-red-500/30",
  blue: "bg-sky-500/20 text-sky-400 border-sky-500/30",
  default: "bg-[#334155]/60 text-[#94A3B8] border-[#334155]",
};

export function Badge({ children, variant = "default", className = "" }: BadgeProps) {
  return (
    <span
      style={{ fontSize: "0.7rem", fontWeight: 600 }}
      className={`inline-flex items-center px-2 py-0.5 rounded-full border uppercase tracking-wider ${variants[variant]} ${className}`}
    >
      {children}
    </span>
  );
}
