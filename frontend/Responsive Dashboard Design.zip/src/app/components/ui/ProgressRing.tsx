import React from "react";

interface ProgressRingProps {
  value: number;
  max?: number;
  size?: number;
  strokeWidth?: number;
  color?: string;
  trackColor?: string;
  label?: string;
  sublabel?: string;
  showValue?: boolean;
}

export function ProgressRing({
  value,
  max = 100,
  size = 160,
  strokeWidth = 12,
  color = "#6366F1",
  trackColor = "#1E293B",
  label,
  sublabel,
  showValue = true,
}: ProgressRingProps) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const progress = Math.min(value / max, 1);
  const strokeDashoffset = circumference * (1 - progress);

  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={trackColor}
          strokeWidth={strokeWidth}
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          style={{ transition: "stroke-dashoffset 1s ease" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        {showValue && (
          <span style={{ fontSize: "2rem", fontWeight: 800 }} className="text-[#F1F5F9]">
            {value}
          </span>
        )}
        {label && <span style={{ fontSize: "0.7rem", fontWeight: 600 }} className="text-[#94A3B8] uppercase tracking-wider text-center px-2">{label}</span>}
        {sublabel && <span style={{ fontSize: "0.7rem" }} className="text-[#94A3B8]">{sublabel}</span>}
      </div>
    </div>
  );
}
