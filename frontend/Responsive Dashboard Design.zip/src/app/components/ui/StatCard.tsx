import React from "react";
import { LucideIcon } from "lucide-react";

interface StatCardProps {
  label: string;
  value: string | number;
  icon: LucideIcon;
  iconColor?: string;
  iconBg?: string;
  trend?: number;
  progress?: number;
  progressColor?: string;
  subtitle?: string;
}

export function StatCard({
  label,
  value,
  icon: Icon,
  iconColor = "#6366F1",
  iconBg = "rgba(99,102,241,0.15)",
  trend,
  progress,
  progressColor = "#6366F1",
  subtitle,
}: StatCardProps) {
  return (
    <div className="rounded-2xl border border-[#334155] bg-[#1E293B] p-5 flex flex-col gap-3 hover:border-[#6366F1]/40 transition-colors duration-200">
      <div className="flex items-start justify-between">
        <div>
          <p style={{ fontSize: "0.75rem", fontWeight: 500 }} className="text-[#94A3B8] uppercase tracking-wider mb-1">{label}</p>
          <p style={{ fontSize: "1.75rem", fontWeight: 700 }} className="text-[#F1F5F9]">{value}</p>
          {subtitle && <p style={{ fontSize: "0.75rem" }} className="text-[#94A3B8] mt-0.5">{subtitle}</p>}
        </div>
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
          style={{ backgroundColor: iconBg }}
        >
          <Icon size={20} color={iconColor} />
        </div>
      </div>

      {progress !== undefined && (
        <div className="w-full bg-[#0F172A] rounded-full h-1.5">
          <div
            className="h-1.5 rounded-full transition-all duration-500"
            style={{ width: `${Math.min(progress, 100)}%`, backgroundColor: progressColor }}
          />
        </div>
      )}

      {trend !== undefined && (
        <div className="flex items-center gap-1">
          <span
            style={{ fontSize: "0.72rem", fontWeight: 600 }}
            className={trend >= 0 ? "text-[#22C55E]" : "text-red-400"}
          >
            {trend >= 0 ? "▲" : "▼"} {Math.abs(trend)}%
          </span>
          <span style={{ fontSize: "0.72rem" }} className="text-[#94A3B8]">vs last month</span>
        </div>
      )}
    </div>
  );
}
