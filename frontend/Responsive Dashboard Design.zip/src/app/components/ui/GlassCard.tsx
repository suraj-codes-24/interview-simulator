import React from "react";

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  glow?: boolean;
  onClick?: () => void;
}

export function GlassCard({ children, className = "", glow = false, onClick }: GlassCardProps) {
  return (
    <div
      onClick={onClick}
      className={`rounded-2xl border border-[#334155] bg-[#1E293B]/80 backdrop-blur-md ${glow ? "glow-pulse" : ""} ${onClick ? "cursor-pointer hover:border-[#6366F1]/50 transition-colors duration-200" : ""} ${className}`}
    >
      {children}
    </div>
  );
}
