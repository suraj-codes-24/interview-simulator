import React, { useState } from "react";
import { NavLink, useNavigate } from "react-router";
import { Brain, BarChart2, LayoutDashboard, Play, User, Menu, X, Bell, ChevronDown } from "lucide-react";

const navItems = [
  { to: "/app", label: "Dashboard", icon: LayoutDashboard, end: true },
  { to: "/app/analytics", label: "Analytics", icon: BarChart2, end: false },
  { to: "/interview", label: "Interview", icon: Play, end: false },
];

export function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const navigate = useNavigate();

  return (
    <header className="sticky top-0 z-50 w-full border-b border-[#334155] bg-[#0F172A]/90 backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => navigate("/app")}>
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#6366F1] to-[#818CF8] flex items-center justify-center">
              <Brain size={18} className="text-white" />
            </div>
            <span style={{ fontSize: "1rem", fontWeight: 700 }} className="text-[#F1F5F9] hidden sm:block">
              InterviewAI
            </span>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map(({ to, label, icon: Icon, end }) => (
              <NavLink
                key={to}
                to={to}
                end={end}
                className={({ isActive }) =>
                  `flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-150 ${
                    isActive
                      ? "bg-[#6366F1]/20 text-[#818CF8] border border-[#6366F1]/30"
                      : "text-[#94A3B8] hover:text-[#F1F5F9] hover:bg-[#1E293B]"
                  }`
                }
                style={{ fontSize: "0.875rem", fontWeight: 500 }}
              >
                <Icon size={16} />
                {label}
              </NavLink>
            ))}
          </nav>

          {/* Right side */}
          <div className="flex items-center gap-3">
            <button className="relative w-8 h-8 rounded-lg bg-[#1E293B] border border-[#334155] flex items-center justify-center text-[#94A3B8] hover:text-[#F1F5F9] transition-colors">
              <Bell size={16} />
              <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-[#6366F1]" />
            </button>

            <div className="relative">
              <button
                onClick={() => setProfileOpen(!profileOpen)}
                className="flex items-center gap-2 px-2 py-1.5 rounded-lg bg-[#1E293B] border border-[#334155] hover:border-[#6366F1]/40 transition-colors"
              >
                <div className="w-6 h-6 rounded-full bg-gradient-to-br from-[#6366F1] to-[#22C55E] flex items-center justify-center">
                  <User size={13} className="text-white" />
                </div>
                <span style={{ fontSize: "0.8rem", fontWeight: 500 }} className="text-[#F1F5F9] hidden sm:block">Aryan</span>
                <ChevronDown size={14} className="text-[#94A3B8]" />
              </button>
              {profileOpen && (
                <div className="absolute right-0 top-full mt-2 w-44 rounded-xl border border-[#334155] bg-[#1E293B] py-1 shadow-2xl">
                  {[
                    { label: "Profile", action: () => {} },
                    { label: "Settings", action: () => {} },
                    { label: "Sign Out", action: () => navigate("/login") },
                  ].map(({ label, action }) => (
                    <button
                      key={label}
                      onClick={() => { action(); setProfileOpen(false); }}
                      style={{ fontSize: "0.8rem" }}
                      className="w-full text-left px-4 py-2 text-[#94A3B8] hover:text-[#F1F5F9] hover:bg-[#334155]/50 transition-colors"
                    >
                      {label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Mobile menu toggle */}
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="md:hidden w-8 h-8 rounded-lg bg-[#1E293B] border border-[#334155] flex items-center justify-center text-[#94A3B8]"
            >
              {mobileOpen ? <X size={16} /> : <Menu size={16} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="md:hidden border-t border-[#334155] bg-[#0F172A] px-4 py-3 flex flex-col gap-1">
          {navItems.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              onClick={() => setMobileOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-2.5 px-4 py-2.5 rounded-lg transition-all ${
                  isActive
                    ? "bg-[#6366F1]/20 text-[#818CF8]"
                    : "text-[#94A3B8] hover:text-[#F1F5F9] hover:bg-[#1E293B]"
                }`
              }
              style={{ fontSize: "0.875rem", fontWeight: 500 }}
            >
              <Icon size={16} />
              {label}
            </NavLink>
          ))}
        </div>
      )}
    </header>
  );
}
