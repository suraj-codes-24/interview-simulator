import { createBrowserRouter } from "react-router";
import { LandingPage } from "./components/pages/LandingPage";
import { LoginPage } from "./components/pages/LoginPage";
import { DashboardPage } from "./components/pages/DashboardPage";
import { InterviewRoomPage } from "./components/pages/InterviewRoomPage";
import { ResultsPage } from "./components/pages/ResultsPage";
import { AnalyticsPage } from "./components/pages/AnalyticsPage";
import { Root } from "./components/layout/Root";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: LandingPage,
  },
  {
    path: "/login",
    Component: LoginPage,
  },
  {
    path: "/interview",
    Component: InterviewRoomPage,
  },
  {
    path: "/app",
    Component: Root,
    children: [
      { index: true, Component: DashboardPage },
      { path: "analytics", Component: AnalyticsPage },
      { path: "results", Component: ResultsPage },
    ],
  },
]);
