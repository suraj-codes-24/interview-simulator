Design a complete modern web application UI for an **AI Multimodal Interview Simulator**.
The application should look like a **professional AI SaaS platform** similar to Linear, Vercel, or Notion.

STYLE AND THEME:

Use a **dark aesthetic theme** with soft gradients and glassmorphism cards.
The design should feel futuristic, minimal, and clean.

Color palette:

Background: #0F172A (deep navy dark)
Primary accent: #6366F1 (AI purple)
Secondary accent: #22C55E (success green)
Card background: #1E293B
Border color: #334155
Text primary: #F1F5F9
Text secondary: #94A3B8

Add subtle gradients and glowing accents around important UI elements.

Typography:

Primary font: Inter
Headings: bold and clean
Body text: medium weight
Spacing should feel airy and professional.

Design language:

• Rounded corners (16px)
• Soft shadows
• Glassmorphism effect on cards
• Smooth layout grid
• Minimal clutter
• Professional developer-focused UI

Create the following pages.

---

PAGE 1 — LANDING PAGE

Hero section introducing the product.

Include:

• large heading: “AI Interview Simulator”
• subtitle describing AI powered interview practice
• call to action button “Start Mock Interview”
• secondary button “View Demo”

Visual element:

show a mock interview interface illustration with an AI avatar interviewer and a user webcam.

Sections below hero:

Features section with 4 feature cards:

1. AI Technical Interviews
2. HR Behavioral Interviews
3. Voice Confidence Analysis
4. Facial Expression Analysis

How it works section with steps:

1. Start Interview
2. Answer Questions
3. AI Evaluates Performance
4. Get Detailed Analytics

Footer with links and social icons.

---

PAGE 2 — LOGIN / SIGNUP PAGE

Create a clean authentication screen.

Split screen layout:

Left side:
AI themed illustration showing interview simulation.

Right side:
login form card.

Fields:

• email
• password

Buttons:

• Login
• Continue with Google

Link:

“Create account”

Use soft glowing borders and minimal UI.

---

PAGE 3 — USER DASHBOARD

Create a modern analytics dashboard.

Top navigation bar:

• Logo
• Dashboard
• Interviews
• Analytics
• Profile avatar

Main dashboard sections:

USER PROFILE CARD

Show:

• Name
• Branch
• Year
• Total interviews completed

PERFORMANCE SUMMARY

Create 4 statistic cards:

• Average Interview Score
• Technical Score
• HR Score
• Confidence Score

Use icons and subtle progress indicators.

START INTERVIEW SECTION

Buttons:

• Start Technical Interview
• Start HR Interview

Options panel:

• topic dropdown
• difficulty selection
• number of questions

RECENT INTERVIEWS TABLE

Columns:

Date | Type | Topic | Score | Duration

---

PAGE 4 — INTERVIEW ROOM (CORE FEATURE)

Design a realistic interview environment.

Layout should look like a **video interview platform**.

Three main sections.

LEFT PANEL — AI INTERVIEWER

Display an animated AI avatar interviewer.

Elements:

• circular avatar
• speaking animation indicator
• status label (Asking Question / Listening / Evaluating)

Avatar dialogue box showing the question.

Example:

“Explain the concept of a binary search tree.”

---

RIGHT PANEL — USER CAMERA

Display webcam feed area.

Overlay indicators:

• Eye Contact Score
• Confidence Level
• Emotion Detection

Include a small camera frame with rounded edges.

---

BOTTOM PANEL — ANSWER AREA

Controls for answering.

Options:

🎤 Record Voice
⌨️ Type Answer

Include microphone visualization waveform.

Also include:

Next Question button
End Interview button

Add interview progress indicator.

Example:

Question 2 / 5
Timer countdown

---

PAGE 5 — RESULTS PAGE

Show final interview evaluation.

Top section:

Large circular score indicator.

Example:

Overall Score: 84 / 100

Breakdown cards:

• NLP Content Score
• Voice Fluency Score
• Facial Expression Score
• Behavioral Structure Score

Visualizations:

Bar charts and radar charts showing strengths and weaknesses.

Feedback section:

Strengths:
• Clear explanation
• Good technical accuracy

Weaknesses:
• Eye contact
• Speaking pace

Button:

“Start Another Interview”

---

PAGE 6 — ANALYTICS PAGE

Create a professional analytics dashboard.

Charts:

• score progression line chart
• radar chart for skills
• topic weakness heatmap
• interview history graph

Include filters for:

• interview type
• topic
• difficulty

Design should feel similar to a professional data analytics SaaS platform.

---

OVERALL DESIGN GOAL

The application should feel like a **real AI startup product**, not a student project.

Focus on:

• modern SaaS UI
• clear hierarchy
• elegant dark aesthetic
• smooth spacing
• minimal clutter
• strong visual polish
