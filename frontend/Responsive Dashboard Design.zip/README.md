
  # Responsive Dashboard Design

  This is a code bundle for Responsive Dashboard Design. The original project is available at https://www.figma.com/design/TKldd1cD4tRuzav9UurS3l/Responsive-Dashboard-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  